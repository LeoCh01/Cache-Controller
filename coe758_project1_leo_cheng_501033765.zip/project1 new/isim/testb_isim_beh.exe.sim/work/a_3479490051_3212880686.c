/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x8ddf5b5d */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "Function state_to_bin ended without a return statement";
static const char *ng1 = "/home/student2/l1cheng/coe758/project1 new/CacheController.vhd";
extern char *IEEE_P_1242562249;
extern char *IEEE_P_2592010699;

char *ieee_p_1242562249_sub_10420449594411817395_1035706684(char *, char *, int , int );
int ieee_p_1242562249_sub_17802405650254020620_1035706684(char *, char *, char *);


char *work_a_3479490051_3212880686_sub_1498982053589814668_3057020925(char *t1, char *t2, unsigned char t3)
{
    char t5[8];
    char *t0;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    int t12;
    unsigned int t13;
    static char *nl0[] = {&&LAB7, &&LAB3, &&LAB4, &&LAB5, &&LAB6, &&LAB8};

LAB0:    t6 = (t5 + 4U);
    *((unsigned char *)t6) = t3;
    t7 = (char *)((nl0) + t3);
    goto **((char **)t7);

LAB2:    xsi_error(ng0);
    t0 = 0;

LAB1:    return t0;
LAB3:    t8 = (t1 + 15305);
    t0 = xsi_get_transient_memory(3U);
    memcpy(t0, t8, 3U);
    t10 = (t2 + 0U);
    t11 = (t10 + 0U);
    *((int *)t11) = 1;
    t11 = (t10 + 4U);
    *((int *)t11) = 3;
    t11 = (t10 + 8U);
    *((int *)t11) = 1;
    t12 = (3 - 1);
    t13 = (t12 * 1);
    t13 = (t13 + 1);
    t11 = (t10 + 12U);
    *((unsigned int *)t11) = t13;
    goto LAB1;

LAB4:    t7 = (t1 + 15308);
    t0 = xsi_get_transient_memory(3U);
    memcpy(t0, t7, 3U);
    t9 = (t2 + 0U);
    t10 = (t9 + 0U);
    *((int *)t10) = 1;
    t10 = (t9 + 4U);
    *((int *)t10) = 3;
    t10 = (t9 + 8U);
    *((int *)t10) = 1;
    t12 = (3 - 1);
    t13 = (t12 * 1);
    t13 = (t13 + 1);
    t10 = (t9 + 12U);
    *((unsigned int *)t10) = t13;
    goto LAB1;

LAB5:    t7 = (t1 + 15311);
    t0 = xsi_get_transient_memory(3U);
    memcpy(t0, t7, 3U);
    t9 = (t2 + 0U);
    t10 = (t9 + 0U);
    *((int *)t10) = 1;
    t10 = (t9 + 4U);
    *((int *)t10) = 3;
    t10 = (t9 + 8U);
    *((int *)t10) = 1;
    t12 = (3 - 1);
    t13 = (t12 * 1);
    t13 = (t13 + 1);
    t10 = (t9 + 12U);
    *((unsigned int *)t10) = t13;
    goto LAB1;

LAB6:    t7 = (t1 + 15314);
    t0 = xsi_get_transient_memory(3U);
    memcpy(t0, t7, 3U);
    t9 = (t2 + 0U);
    t10 = (t9 + 0U);
    *((int *)t10) = 1;
    t10 = (t9 + 4U);
    *((int *)t10) = 3;
    t10 = (t9 + 8U);
    *((int *)t10) = 1;
    t12 = (3 - 1);
    t13 = (t12 * 1);
    t13 = (t13 + 1);
    t10 = (t9 + 12U);
    *((unsigned int *)t10) = t13;
    goto LAB1;

LAB7:    t7 = (t1 + 15317);
    t0 = xsi_get_transient_memory(3U);
    memcpy(t0, t7, 3U);
    t9 = (t2 + 0U);
    t10 = (t9 + 0U);
    *((int *)t10) = 1;
    t10 = (t9 + 4U);
    *((int *)t10) = 3;
    t10 = (t9 + 8U);
    *((int *)t10) = 1;
    t12 = (3 - 1);
    t13 = (t12 * 1);
    t13 = (t13 + 1);
    t10 = (t9 + 12U);
    *((unsigned int *)t10) = t13;
    goto LAB1;

LAB8:    t7 = (t1 + 15320);
    t0 = xsi_get_transient_memory(3U);
    memcpy(t0, t7, 3U);
    t9 = (t2 + 0U);
    t10 = (t9 + 0U);
    *((int *)t10) = 1;
    t10 = (t9 + 4U);
    *((int *)t10) = 3;
    t10 = (t9 + 8U);
    *((int *)t10) = 1;
    t12 = (3 - 1);
    t13 = (t12 * 1);
    t13 = (t13 + 1);
    t10 = (t9 + 12U);
    *((unsigned int *)t10) = t13;
    goto LAB1;

LAB9:    t7 = (t1 + 15323);
    t0 = xsi_get_transient_memory(3U);
    memcpy(t0, t7, 3U);
    t9 = (t2 + 0U);
    t10 = (t9 + 0U);
    *((int *)t10) = 1;
    t10 = (t9 + 4U);
    *((int *)t10) = 3;
    t10 = (t9 + 8U);
    *((int *)t10) = 1;
    t12 = (3 - 1);
    t13 = (t12 * 1);
    t13 = (t13 + 1);
    t10 = (t9 + 12U);
    *((unsigned int *)t10) = t13;
    goto LAB1;

LAB10:    goto LAB2;

LAB11:    goto LAB2;

LAB12:    goto LAB2;

LAB13:    goto LAB2;

LAB14:    goto LAB2;

LAB15:    goto LAB2;

LAB16:    goto LAB2;

}

static void work_a_3479490051_3212880686_p_0(char *t0)
{
    char t35[16];
    char t36[16];
    char t37[16];
    char t39[16];
    unsigned char t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    unsigned char t6;
    unsigned char t7;
    char *t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    int t17;
    int t18;
    int t19;
    int t20;
    unsigned int t21;
    unsigned int t22;
    unsigned int t23;
    char *t24;
    unsigned int t25;
    char *t26;
    char *t27;
    char *t28;
    unsigned char t29;
    unsigned char t30;
    char *t31;
    char *t32;
    char *t33;
    char *t34;
    int t38;
    char *t40;
    char *t41;
    static char *nl0[] = {&&LAB14, &&LAB9, &&LAB10, &&LAB11, &&LAB12, &&LAB13};

LAB0:    xsi_set_current_line(179, ng1);
    t2 = (t0 + 992U);
    t3 = xsi_signal_has_event(t2);
    if (t3 == 1)
        goto LAB5;

LAB6:    t1 = (unsigned char)0;

LAB7:    if (t1 != 0)
        goto LAB2;

LAB4:
LAB3:    t2 = (t0 + 7944);
    *((int *)t2) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(180, ng1);
    t4 = (t0 + 1992U);
    t8 = *((char **)t4);
    t9 = (15 - 15);
    t10 = (t9 * 1U);
    t11 = (0 + t10);
    t4 = (t8 + t11);
    t12 = (t0 + 8024);
    t13 = (t12 + 56U);
    t14 = *((char **)t13);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    memcpy(t16, t4, 8U);
    xsi_driver_first_trans_fast(t12);
    xsi_set_current_line(181, ng1);
    t2 = (t0 + 1992U);
    t4 = *((char **)t2);
    t9 = (15 - 7);
    t10 = (t9 * 1U);
    t11 = (0 + t10);
    t2 = (t4 + t11);
    t5 = (t0 + 8088);
    t8 = (t5 + 56U);
    t12 = *((char **)t8);
    t13 = (t12 + 56U);
    t14 = *((char **)t13);
    memcpy(t14, t2, 3U);
    xsi_driver_first_trans_fast(t5);
    xsi_set_current_line(182, ng1);
    t2 = (t0 + 1992U);
    t4 = *((char **)t2);
    t9 = (15 - 4);
    t10 = (t9 * 1U);
    t11 = (0 + t10);
    t2 = (t4 + t11);
    t5 = (t0 + 8152);
    t8 = (t5 + 56U);
    t12 = *((char **)t8);
    t13 = (t12 + 56U);
    t14 = *((char **)t13);
    memcpy(t14, t2, 5U);
    xsi_driver_first_trans_fast(t5);
    xsi_set_current_line(184, ng1);
    t2 = (t0 + 6472U);
    t4 = *((char **)t2);
    t1 = *((unsigned char *)t4);
    t2 = (char *)((nl0) + t1);
    goto **((char **)t2);

LAB5:    t4 = (t0 + 1032U);
    t5 = *((char **)t4);
    t6 = *((unsigned char *)t5);
    t7 = (t6 == (unsigned char)3);
    t1 = t7;
    goto LAB7;

LAB8:    goto LAB3;

LAB9:    xsi_set_current_line(186, ng1);
    t5 = (t0 + 8216);
    t8 = (t5 + 56U);
    t12 = *((char **)t8);
    t13 = (t12 + 56U);
    t14 = *((char **)t13);
    *((unsigned char *)t14) = (unsigned char)3;
    xsi_driver_first_trans_fast(t5);
    xsi_set_current_line(187, ng1);
    t2 = (t0 + 2312U);
    t4 = *((char **)t2);
    t1 = *((unsigned char *)t4);
    t3 = (t1 == (unsigned char)3);
    if (t3 != 0)
        goto LAB16;

LAB18:
LAB17:    goto LAB8;

LAB10:    xsi_set_current_line(193, ng1);
    t2 = (t0 + 4872U);
    t4 = *((char **)t2);
    t2 = (t0 + 5192U);
    t5 = *((char **)t2);
    t2 = (t0 + 14808U);
    t17 = ieee_p_1242562249_sub_17802405650254020620_1035706684(IEEE_P_1242562249, t5, t2);
    t18 = (t17 - 7);
    t9 = (t18 * -1);
    xsi_vhdl_check_range_of_index(7, 0, -1, t17);
    t10 = (1U * t9);
    t11 = (0 + t10);
    t8 = (t4 + t11);
    t3 = *((unsigned char *)t8);
    t6 = (t3 == (unsigned char)3);
    if (t6 == 1)
        goto LAB22;

LAB23:    t1 = (unsigned char)0;

LAB24:    if (t1 != 0)
        goto LAB19;

LAB21:    xsi_set_current_line(209, ng1);
    t2 = (t0 + 4712U);
    t4 = *((char **)t2);
    t2 = (t0 + 5192U);
    t5 = *((char **)t2);
    t2 = (t0 + 14808U);
    t17 = ieee_p_1242562249_sub_17802405650254020620_1035706684(IEEE_P_1242562249, t5, t2);
    t18 = (t17 - 7);
    t9 = (t18 * -1);
    xsi_vhdl_check_range_of_index(7, 0, -1, t17);
    t10 = (1U * t9);
    t11 = (0 + t10);
    t8 = (t4 + t11);
    t1 = *((unsigned char *)t8);
    t3 = (t1 == (unsigned char)3);
    if (t3 != 0)
        goto LAB36;

LAB38:    xsi_set_current_line(212, ng1);
    t2 = (t0 + 8280);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t8 = (t5 + 56U);
    t12 = *((char **)t8);
    *((unsigned char *)t12) = (unsigned char)4;
    xsi_driver_first_trans_fast(t2);

LAB37:
LAB20:    goto LAB8;

LAB11:    xsi_set_current_line(217, ng1);
    t2 = (t0 + 5512U);
    t4 = *((char **)t2);
    t17 = *((int *)t4);
    t1 = (t17 == 64);
    if (t1 != 0)
        goto LAB39;

LAB41:    xsi_set_current_line(224, ng1);
    t2 = (t0 + 5512U);
    t4 = *((char **)t2);
    t17 = *((int *)t4);
    t18 = xsi_vhdl_mod(t17, 2);
    t1 = (t18 == 0);
    if (t1 != 0)
        goto LAB42;

LAB44:    xsi_set_current_line(229, ng1);
    t2 = (t0 + 8728);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t8 = (t5 + 56U);
    t12 = *((char **)t8);
    *((unsigned char *)t12) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(230, ng1);
    t2 = (t0 + 4552U);
    t4 = *((char **)t2);
    t2 = (t0 + 5192U);
    t5 = *((char **)t2);
    t2 = (t0 + 14808U);
    t17 = ieee_p_1242562249_sub_17802405650254020620_1035706684(IEEE_P_1242562249, t5, t2);
    t18 = (t17 - 0);
    t9 = (t18 * 1);
    xsi_vhdl_check_range_of_index(0, 7, 1, t17);
    t10 = (8U * t9);
    t11 = (0 + t10);
    t8 = (t4 + t11);
    t12 = (t0 + 5192U);
    t13 = *((char **)t12);
    t14 = ((IEEE_P_2592010699) + 4000);
    t15 = (t36 + 0U);
    t16 = (t15 + 0U);
    *((int *)t16) = 7;
    t16 = (t15 + 4U);
    *((int *)t16) = 0;
    t16 = (t15 + 8U);
    *((int *)t16) = -1;
    t19 = (0 - 7);
    t21 = (t19 * -1);
    t21 = (t21 + 1);
    t16 = (t15 + 12U);
    *((unsigned int *)t16) = t21;
    t16 = (t0 + 14808U);
    t12 = xsi_base_array_concat(t12, t35, t14, (char)97, t8, t36, (char)97, t13, t16, (char)101);
    t24 = (t0 + 5512U);
    t26 = *((char **)t24);
    t20 = *((int *)t26);
    t38 = (t20 / 2);
    t24 = ieee_p_1242562249_sub_10420449594411817395_1035706684(IEEE_P_1242562249, t37, t38, 5);
    t28 = ((IEEE_P_2592010699) + 4000);
    t27 = xsi_base_array_concat(t27, t39, t28, (char)97, t12, t35, (char)97, t24, t37, (char)101);
    t21 = (8U + 3U);
    t31 = (t37 + 12U);
    t22 = *((unsigned int *)t31);
    t22 = (t22 * 1U);
    t23 = (t21 + t22);
    t1 = (16U != t23);
    if (t1 == 1)
        goto LAB47;

LAB48:    t32 = (t0 + 8792);
    t33 = (t32 + 56U);
    t34 = *((char **)t33);
    t40 = (t34 + 56U);
    t41 = *((char **)t40);
    memcpy(t41, t27, 16U);
    xsi_driver_first_trans_fast(t32);
    xsi_set_current_line(231, ng1);
    t2 = (t0 + 3432U);
    t4 = *((char **)t2);
    t2 = (t0 + 8856);
    t5 = (t2 + 56U);
    t8 = *((char **)t5);
    t12 = (t8 + 56U);
    t13 = *((char **)t12);
    memcpy(t13, t4, 8U);
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(232, ng1);
    t2 = (t0 + 8664);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t8 = (t5 + 56U);
    t12 = *((char **)t8);
    *((unsigned char *)t12) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);

LAB43:    xsi_set_current_line(234, ng1);
    t2 = (t0 + 5512U);
    t4 = *((char **)t2);
    t17 = *((int *)t4);
    t18 = (t17 + 1);
    t2 = (t0 + 8600);
    t5 = (t2 + 56U);
    t8 = *((char **)t5);
    t12 = (t8 + 56U);
    t13 = *((char **)t12);
    *((int *)t13) = t18;
    xsi_driver_first_trans_fast(t2);

LAB40:    goto LAB8;

LAB12:    xsi_set_current_line(238, ng1);
    t2 = (t0 + 5512U);
    t4 = *((char **)t2);
    t17 = *((int *)t4);
    t1 = (t17 == 64);
    if (t1 != 0)
        goto LAB49;

LAB51:    xsi_set_current_line(245, ng1);
    t2 = (t0 + 5512U);
    t4 = *((char **)t2);
    t17 = *((int *)t4);
    t18 = xsi_vhdl_mod(t17, 2);
    t1 = (t18 == 0);
    if (t1 != 0)
        goto LAB52;

LAB54:    xsi_set_current_line(250, ng1);
    t2 = (t0 + 8344);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t8 = (t5 + 56U);
    t12 = *((char **)t8);
    *((unsigned char *)t12) = (unsigned char)3;
    xsi_driver_first_trans_delta(t2, 0U, 1, 0LL);
    xsi_set_current_line(251, ng1);
    t2 = (t0 + 5192U);
    t4 = *((char **)t2);
    t2 = (t0 + 5512U);
    t5 = *((char **)t2);
    t17 = *((int *)t5);
    t18 = (t17 / 2);
    t19 = (t18 - 1);
    t2 = ieee_p_1242562249_sub_10420449594411817395_1035706684(IEEE_P_1242562249, t35, t19, 5);
    t12 = ((IEEE_P_2592010699) + 4000);
    t13 = (t0 + 14808U);
    t8 = xsi_base_array_concat(t8, t36, t12, (char)97, t4, t13, (char)97, t2, t35, (char)101);
    t14 = (t35 + 12U);
    t9 = *((unsigned int *)t14);
    t9 = (t9 * 1U);
    t10 = (3U + t9);
    t1 = (8U != t10);
    if (t1 == 1)
        goto LAB57;

LAB58:    t15 = (t0 + 8536);
    t16 = (t15 + 56U);
    t24 = *((char **)t16);
    t26 = (t24 + 56U);
    t27 = *((char **)t26);
    memcpy(t27, t8, 8U);
    xsi_driver_first_trans_fast(t15);
    xsi_set_current_line(252, ng1);
    t2 = (t0 + 4392U);
    t4 = *((char **)t2);
    t2 = (t0 + 8408);
    t5 = (t2 + 56U);
    t8 = *((char **)t5);
    t12 = (t8 + 56U);
    t13 = *((char **)t12);
    memcpy(t13, t4, 8U);
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(253, ng1);
    t2 = (t0 + 8664);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t8 = (t5 + 56U);
    t12 = *((char **)t8);
    *((unsigned char *)t12) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);

LAB53:    xsi_set_current_line(255, ng1);
    t2 = (t0 + 5512U);
    t4 = *((char **)t2);
    t17 = *((int *)t4);
    t18 = (t17 + 1);
    t2 = (t0 + 8600);
    t5 = (t2 + 56U);
    t8 = *((char **)t5);
    t12 = (t8 + 56U);
    t13 = *((char **)t12);
    *((int *)t13) = t18;
    xsi_driver_first_trans_fast(t2);

LAB50:    goto LAB8;

LAB13:    xsi_set_current_line(259, ng1);
    t2 = (t0 + 3432U);
    t4 = *((char **)t2);
    t2 = (t0 + 9048);
    t5 = (t2 + 56U);
    t8 = *((char **)t5);
    t12 = (t8 + 56U);
    t13 = *((char **)t12);
    memcpy(t13, t4, 8U);
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(260, ng1);
    t2 = (t0 + 5032U);
    t4 = *((char **)t2);
    t2 = (t0 + 5192U);
    t5 = *((char **)t2);
    t2 = (t0 + 14808U);
    t17 = ieee_p_1242562249_sub_17802405650254020620_1035706684(IEEE_P_1242562249, t5, t2);
    t18 = (t17 - 0);
    t9 = (t18 * 1);
    t10 = (8U * t9);
    t11 = (0U + t10);
    t8 = (t0 + 8984);
    t12 = (t8 + 56U);
    t13 = *((char **)t12);
    t14 = (t13 + 56U);
    t15 = *((char **)t14);
    memcpy(t15, t4, 8U);
    xsi_driver_first_trans_delta(t8, t11, 8U, 0LL);
    xsi_set_current_line(261, ng1);
    t2 = (t0 + 8280);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t8 = (t5 + 56U);
    t12 = *((char **)t8);
    *((unsigned char *)t12) = (unsigned char)1;
    xsi_driver_first_trans_fast(t2);
    goto LAB8;

LAB14:    xsi_set_current_line(264, ng1);
    t2 = (t0 + 8216);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t8 = (t5 + 56U);
    t12 = *((char **)t8);
    *((unsigned char *)t12) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(265, ng1);
    t2 = (t0 + 8280);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t8 = (t5 + 56U);
    t12 = *((char **)t8);
    *((unsigned char *)t12) = (unsigned char)1;
    xsi_driver_first_trans_fast(t2);
    goto LAB8;

LAB15:    xsi_set_current_line(267, ng1);
    t2 = (t0 + 8280);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t8 = (t5 + 56U);
    t12 = *((char **)t8);
    *((unsigned char *)t12) = (unsigned char)1;
    xsi_driver_first_trans_fast(t2);
    goto LAB8;

LAB16:    xsi_set_current_line(188, ng1);
    t2 = (t0 + 8280);
    t5 = (t2 + 56U);
    t8 = *((char **)t5);
    t12 = (t8 + 56U);
    t13 = *((char **)t12);
    *((unsigned char *)t13) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(189, ng1);
    t2 = (t0 + 8216);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t8 = (t5 + 56U);
    t12 = *((char **)t8);
    *((unsigned char *)t12) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    goto LAB17;

LAB19:    xsi_set_current_line(195, ng1);
    t27 = (t0 + 2152U);
    t28 = *((char **)t27);
    t29 = *((unsigned char *)t28);
    t30 = (t29 == (unsigned char)3);
    if (t30 != 0)
        goto LAB31;

LAB33:    xsi_set_current_line(202, ng1);
    t2 = (t0 + 8344);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t8 = (t5 + 56U);
    t12 = *((char **)t8);
    *((unsigned char *)t12) = (unsigned char)2;
    xsi_driver_first_trans_delta(t2, 0U, 1, 0LL);

LAB32:    xsi_set_current_line(205, ng1);
    t2 = (t0 + 5192U);
    t4 = *((char **)t2);
    t2 = (t0 + 5352U);
    t5 = *((char **)t2);
    t8 = ((IEEE_P_2592010699) + 4000);
    t12 = (t0 + 14808U);
    t13 = (t0 + 14824U);
    t2 = xsi_base_array_concat(t2, t35, t8, (char)97, t4, t12, (char)97, t5, t13, (char)101);
    t9 = (3U + 5U);
    t1 = (8U != t9);
    if (t1 == 1)
        goto LAB34;

LAB35:    t14 = (t0 + 8536);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    t24 = (t16 + 56U);
    t26 = *((char **)t24);
    memcpy(t26, t2, 8U);
    xsi_driver_first_trans_fast(t14);
    xsi_set_current_line(206, ng1);
    t2 = (t0 + 8280);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t8 = (t5 + 56U);
    t12 = *((char **)t8);
    *((unsigned char *)t12) = (unsigned char)5;
    xsi_driver_first_trans_fast(t2);
    goto LAB20;

LAB22:    t12 = (t0 + 4552U);
    t13 = *((char **)t12);
    t12 = (t0 + 5192U);
    t14 = *((char **)t12);
    t12 = (t0 + 14808U);
    t19 = ieee_p_1242562249_sub_17802405650254020620_1035706684(IEEE_P_1242562249, t14, t12);
    t20 = (t19 - 0);
    t21 = (t20 * 1);
    xsi_vhdl_check_range_of_index(0, 7, 1, t19);
    t22 = (8U * t21);
    t23 = (0 + t22);
    t15 = (t13 + t23);
    t16 = (t0 + 5032U);
    t24 = *((char **)t16);
    t7 = 1;
    if (8U == 8U)
        goto LAB25;

LAB26:    t7 = 0;

LAB27:    t1 = t7;
    goto LAB24;

LAB25:    t25 = 0;

LAB28:    if (t25 < 8U)
        goto LAB29;
    else
        goto LAB27;

LAB29:    t16 = (t15 + t25);
    t26 = (t24 + t25);
    if (*((unsigned char *)t16) != *((unsigned char *)t26))
        goto LAB26;

LAB30:    t25 = (t25 + 1);
    goto LAB28;

LAB31:    xsi_set_current_line(197, ng1);
    t27 = (t0 + 8344);
    t31 = (t27 + 56U);
    t32 = *((char **)t31);
    t33 = (t32 + 56U);
    t34 = *((char **)t33);
    *((unsigned char *)t34) = (unsigned char)3;
    xsi_driver_first_trans_delta(t27, 0U, 1, 0LL);
    xsi_set_current_line(198, ng1);
    t2 = (t0 + 2952U);
    t4 = *((char **)t2);
    t2 = (t0 + 8408);
    t5 = (t2 + 56U);
    t8 = *((char **)t5);
    t12 = (t8 + 56U);
    t13 = *((char **)t12);
    memcpy(t13, t4, 8U);
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(199, ng1);
    t2 = (t0 + 5192U);
    t4 = *((char **)t2);
    t2 = (t0 + 14808U);
    t17 = ieee_p_1242562249_sub_17802405650254020620_1035706684(IEEE_P_1242562249, t4, t2);
    t18 = (t17 - 7);
    t9 = (t18 * -1);
    t10 = (1 * t9);
    t11 = (0U + t10);
    t5 = (t0 + 8472);
    t8 = (t5 + 56U);
    t12 = *((char **)t8);
    t13 = (t12 + 56U);
    t14 = *((char **)t13);
    *((unsigned char *)t14) = (unsigned char)3;
    xsi_driver_first_trans_delta(t5, t11, 1, 0LL);
    goto LAB32;

LAB34:    xsi_size_not_matching(8U, t9, 0);
    goto LAB35;

LAB36:    xsi_set_current_line(210, ng1);
    t12 = (t0 + 8280);
    t13 = (t12 + 56U);
    t14 = *((char **)t13);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    *((unsigned char *)t16) = (unsigned char)3;
    xsi_driver_first_trans_fast(t12);
    goto LAB37;

LAB39:    xsi_set_current_line(218, ng1);
    t2 = (t0 + 8600);
    t5 = (t2 + 56U);
    t8 = *((char **)t5);
    t12 = (t8 + 56U);
    t13 = *((char **)t12);
    *((int *)t13) = 0;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(219, ng1);
    t2 = (t0 + 8664);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t8 = (t5 + 56U);
    t12 = *((char **)t8);
    *((unsigned char *)t12) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(220, ng1);
    t2 = (t0 + 5192U);
    t4 = *((char **)t2);
    t2 = (t0 + 14808U);
    t17 = ieee_p_1242562249_sub_17802405650254020620_1035706684(IEEE_P_1242562249, t4, t2);
    t18 = (t17 - 7);
    t9 = (t18 * -1);
    t10 = (1 * t9);
    t11 = (0U + t10);
    t5 = (t0 + 8472);
    t8 = (t5 + 56U);
    t12 = *((char **)t8);
    t13 = (t12 + 56U);
    t14 = *((char **)t13);
    *((unsigned char *)t14) = (unsigned char)2;
    xsi_driver_first_trans_delta(t5, t11, 1, 0LL);
    xsi_set_current_line(221, ng1);
    t2 = (t0 + 8280);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t8 = (t5 + 56U);
    t12 = *((char **)t8);
    *((unsigned char *)t12) = (unsigned char)4;
    xsi_driver_first_trans_fast(t2);
    goto LAB40;

LAB42:    xsi_set_current_line(225, ng1);
    t2 = (t0 + 8664);
    t5 = (t2 + 56U);
    t8 = *((char **)t5);
    t12 = (t8 + 56U);
    t13 = *((char **)t12);
    *((unsigned char *)t13) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(226, ng1);
    t2 = (t0 + 8344);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t8 = (t5 + 56U);
    t12 = *((char **)t8);
    *((unsigned char *)t12) = (unsigned char)2;
    xsi_driver_first_trans_delta(t2, 0U, 1, 0LL);
    xsi_set_current_line(227, ng1);
    t2 = (t0 + 5192U);
    t4 = *((char **)t2);
    t2 = (t0 + 5512U);
    t5 = *((char **)t2);
    t17 = *((int *)t5);
    t18 = (t17 / 2);
    t2 = ieee_p_1242562249_sub_10420449594411817395_1035706684(IEEE_P_1242562249, t35, t18, 5);
    t12 = ((IEEE_P_2592010699) + 4000);
    t13 = (t0 + 14808U);
    t8 = xsi_base_array_concat(t8, t36, t12, (char)97, t4, t13, (char)97, t2, t35, (char)101);
    t14 = (t35 + 12U);
    t9 = *((unsigned int *)t14);
    t9 = (t9 * 1U);
    t10 = (3U + t9);
    t1 = (8U != t10);
    if (t1 == 1)
        goto LAB45;

LAB46:    t15 = (t0 + 8536);
    t16 = (t15 + 56U);
    t24 = *((char **)t16);
    t26 = (t24 + 56U);
    t27 = *((char **)t26);
    memcpy(t27, t8, 8U);
    xsi_driver_first_trans_fast(t15);
    goto LAB43;

LAB45:    xsi_size_not_matching(8U, t10, 0);
    goto LAB46;

LAB47:    xsi_size_not_matching(16U, t23, 0);
    goto LAB48;

LAB49:    xsi_set_current_line(239, ng1);
    t2 = (t0 + 8600);
    t5 = (t2 + 56U);
    t8 = *((char **)t5);
    t12 = (t8 + 56U);
    t13 = *((char **)t12);
    *((int *)t13) = 0;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(240, ng1);
    t2 = (t0 + 5192U);
    t4 = *((char **)t2);
    t2 = (t0 + 14808U);
    t17 = ieee_p_1242562249_sub_17802405650254020620_1035706684(IEEE_P_1242562249, t4, t2);
    t18 = (t17 - 7);
    t9 = (t18 * -1);
    t10 = (1 * t9);
    t11 = (0U + t10);
    t5 = (t0 + 8920);
    t8 = (t5 + 56U);
    t12 = *((char **)t8);
    t13 = (t12 + 56U);
    t14 = *((char **)t13);
    *((unsigned char *)t14) = (unsigned char)3;
    xsi_driver_first_trans_delta(t5, t11, 1, 0LL);
    xsi_set_current_line(241, ng1);
    t2 = (t0 + 5032U);
    t4 = *((char **)t2);
    t2 = (t0 + 5192U);
    t5 = *((char **)t2);
    t2 = (t0 + 14808U);
    t17 = ieee_p_1242562249_sub_17802405650254020620_1035706684(IEEE_P_1242562249, t5, t2);
    t18 = (t17 - 0);
    t9 = (t18 * 1);
    t10 = (8U * t9);
    t11 = (0U + t10);
    t8 = (t0 + 8984);
    t12 = (t8 + 56U);
    t13 = *((char **)t12);
    t14 = (t13 + 56U);
    t15 = *((char **)t14);
    memcpy(t15, t4, 8U);
    xsi_driver_first_trans_delta(t8, t11, 8U, 0LL);
    xsi_set_current_line(242, ng1);
    t2 = (t0 + 8280);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t8 = (t5 + 56U);
    t12 = *((char **)t8);
    *((unsigned char *)t12) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    goto LAB50;

LAB52:    xsi_set_current_line(246, ng1);
    t2 = (t0 + 8728);
    t5 = (t2 + 56U);
    t8 = *((char **)t5);
    t12 = (t8 + 56U);
    t13 = *((char **)t12);
    *((unsigned char *)t13) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(247, ng1);
    t2 = (t0 + 5032U);
    t4 = *((char **)t2);
    t2 = (t0 + 5192U);
    t5 = *((char **)t2);
    t8 = ((IEEE_P_2592010699) + 4000);
    t12 = (t0 + 14792U);
    t13 = (t0 + 14808U);
    t2 = xsi_base_array_concat(t2, t35, t8, (char)97, t4, t12, (char)97, t5, t13, (char)101);
    t14 = (t0 + 5512U);
    t15 = *((char **)t14);
    t17 = *((int *)t15);
    t18 = (t17 / 2);
    t14 = ieee_p_1242562249_sub_10420449594411817395_1035706684(IEEE_P_1242562249, t36, t18, 5);
    t24 = ((IEEE_P_2592010699) + 4000);
    t16 = xsi_base_array_concat(t16, t37, t24, (char)97, t2, t35, (char)97, t14, t36, (char)101);
    t9 = (8U + 3U);
    t26 = (t36 + 12U);
    t10 = *((unsigned int *)t26);
    t10 = (t10 * 1U);
    t11 = (t9 + t10);
    t1 = (16U != t11);
    if (t1 == 1)
        goto LAB55;

LAB56:    t27 = (t0 + 8792);
    t28 = (t27 + 56U);
    t31 = *((char **)t28);
    t32 = (t31 + 56U);
    t33 = *((char **)t32);
    memcpy(t33, t16, 16U);
    xsi_driver_first_trans_fast(t27);
    xsi_set_current_line(248, ng1);
    t2 = (t0 + 8664);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t8 = (t5 + 56U);
    t12 = *((char **)t8);
    *((unsigned char *)t12) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    goto LAB53;

LAB55:    xsi_size_not_matching(16U, t11, 0);
    goto LAB56;

LAB57:    xsi_size_not_matching(8U, t10, 0);
    goto LAB58;

}


extern void work_a_3479490051_3212880686_init()
{
	static char *pe[] = {(void *)work_a_3479490051_3212880686_p_0};
	static char *se[] = {(void *)work_a_3479490051_3212880686_sub_1498982053589814668_3057020925};
	xsi_register_didat("work_a_3479490051_3212880686", "isim/testb_isim_beh.exe.sim/work/a_3479490051_3212880686.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}
